let myArray=['a','b','c','d'];
myArray.unshift('start');  //added element to the start of the array
myArray.push('end');        //added element to the end of the array
console.log(myArray);
