for (let i = 0; i <= 10; i++) {
    console.log("Square root of " + i + "is " + i * i + "\n Cube root of " + i + " is " + i * i * i);
}
