let object = {
name : "David Rayy",
sclass : "VI",
rollno : 12 
  };
  let keys = Object.keys(object)
  console.log(keys);
